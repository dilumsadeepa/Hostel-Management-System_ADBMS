create
    definer = admin@`%` procedure InsertUserWithEncryptedPassword(IN p_index_no varchar(20), IN p_username varchar(255),
                                                                  IN p_fullname varchar(255), IN p_email varchar(255),
                                                                  IN p_tel varchar(255), IN p_password varchar(255),
                                                                  IN p_role int)
BEGIN
    DECLARE hashed_password VARCHAR(255);
    SET hashed_password = CONCAT('mysaltprefix', SHA2(p_password, 256));

    INSERT INTO users (index_no, username, fullname, email, tel, password, role)
    VALUES (p_index_no, p_username, p_fullname, p_email, p_tel, hashed_password, p_role);
END;

