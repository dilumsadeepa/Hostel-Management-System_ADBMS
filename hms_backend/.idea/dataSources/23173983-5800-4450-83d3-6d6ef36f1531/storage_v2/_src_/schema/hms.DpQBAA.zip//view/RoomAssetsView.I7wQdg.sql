create definer = admin@`%` view RoomAssetsView as
select `ra`.`room_id`           AS `room_id`,
       `ac`.`category_name`     AS `assets_category_name`,
       sum(`ra`.`no_of_assets`) AS `total_assets`
from (`hms`.`room_assets` `ra` join `hms`.`assets_categories` `ac` on ((`ra`.`asset_id` = `ac`.`id`)))
group by `ac`.`category_name`, `ra`.`room_id`;

