create
    definer = admin@`%` procedure InsertRoomAssets(IN p_room_id int, IN p_assets_category_id int, IN p_no_of_assets int,
                                                   IN p_hostel_id int)
BEGIN
    DECLARE current_assets INT;
    DECLARE allocated_assets INT;
    DECLARE assets_name VARCHAR(255);
    
    SELECT no_of_assets INTO current_assets
    FROM assets
    WHERE assets_category_id = p_assets_category_id AND hostel_id = p_hostel_id;
    
    SELECT category_name INTO assets_name
    FROM assets_categories
    WHERE id = p_assets_category_id;
    
    SELECT COALESCE(SUM(no_of_assets), 0) INTO allocated_assets
    FROM room_assets
    WHERE asset_id = p_assets_category_id;
    
    IF allocated_assets + p_no_of_assets <= current_assets THEN
        
        INSERT INTO room_assets (room_id, asset_id, no_of_assets)
        VALUES (p_room_id, p_assets_category_id, p_no_of_assets);
        
        
        SELECT 'Assets added successfully' AS message, current_assets - (allocated_assets + p_no_of_assets) AS total_assets;
    ELSE
        SELECT CONCAT('Insufficient assets for category: ', assets_name, '. No assets added. Current assets: ', current_assets, ', Allocated assets: ', allocated_assets) AS message, current_assets - allocated_assets AS total_assets;
    END IF;
END;

