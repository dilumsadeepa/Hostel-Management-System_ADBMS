create
    definer = admin@`%` procedure AuthenticateUser(IN p_identifier varchar(255), IN p_password varchar(255))
BEGIN
    
    DECLARE user_id INT;
    DECLARE user_message VARCHAR(255);
    
    
    SELECT id INTO user_id
    FROM users
    WHERE (email = p_identifier OR tel = p_identifier OR index_no = p_identifier) AND password = CONCAT('mysaltprefix', SHA2(p_password, 256));
    
    
    IF user_id IS NOT NULL THEN
        SET user_message = 'Authentication Successful';
    ELSE
        SET user_message = 'Authentication Failed';
    END IF;
    
    
    SELECT user_message AS message, id, index_no, username, fullname, email, tel, role
    FROM users
    WHERE id = user_id;
END;

